#ifndef _I2C_ESP32E_H  
#define _I2C_ESP32E_H

void read_tof();
void init_tof();
uint8_t scanI2C();
#endif
